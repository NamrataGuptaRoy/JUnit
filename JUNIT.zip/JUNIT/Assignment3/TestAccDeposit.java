import static org.junit.Assert.*;

import org.junit.Test;

public class TestAccDeposit {

	@Test
	public void test() {
		AccountDetails a=new AccountDetails();
		float output=a.Deposit();
		assertNotNull(output);
	}

}
