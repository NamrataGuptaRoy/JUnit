import static org.junit.Assert.*;

import org.junit.Test;

public class TestAccBalance {

	@Test
	public void test() {
		AccountDetails a=new AccountDetails();
		float output=a.acctBalance((float) 3400.0);
		assertNotNull(output);
	}

}
