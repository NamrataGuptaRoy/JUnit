import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ TestAccBalance.class, TestAccCard.class, TestAccDeposit.class, TestAccName.class, TestAccNum.class,
		TestAccWithdraw.class })
public class AllTests {

}
