import static org.junit.Assert.*;

import org.junit.Test;

public class TestAccNum {

	@Test
	public void test() {
		AccountDetails a=new AccountDetails();
		int output=a.acctNo(5528);
		assertNotNull(output);
	}

}
