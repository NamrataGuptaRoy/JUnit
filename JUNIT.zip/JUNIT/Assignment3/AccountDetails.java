
public class AccountDetails {
	int acc;
	String name;
	float balance;
	
	int acctNo ( int acc)
	{
		this.acc=acc;
		return acc;
	}
	String acctName ( String name)
	{
		this.name=name;
		return name;
	}
	float acctBalance ( float balance)
	{
		this.balance=balance;
		return balance;
	}
	float Deposit()
	{
		return balance+(float)500.00;
	}
	float Withdraw()
	{
		return balance-(float)500.00;
	}
	int creditCard()
	{
		return (int)(Math.random()*10000)+5;
	}
}
