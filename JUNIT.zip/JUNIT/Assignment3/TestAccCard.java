import static org.junit.Assert.*;

import org.junit.Test;

public class TestAccCard {

	@Test
	public void test() {
		AccountDetails a=new AccountDetails();
		int output=a.creditCard();
		assertTrue(output>0);
	}

}
