import static org.junit.Assert.*;

import org.junit.Test;

public class Assignment1Test {

	@Test
	public void test() {
		Assignment1 ob=new Assignment1();
		assertEquals(4,ob.count("Hi Hello good morning"));
	}

}
