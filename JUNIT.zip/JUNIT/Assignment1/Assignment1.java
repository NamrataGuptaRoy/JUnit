
public class Assignment1 {

	int count(String str)
	{
		int i=0,c=0;
		while(i<str.length())
		{
			if(str.charAt(i)==' ')c++;
			i++;
		}
		
		return c+1;
	}
	
}
