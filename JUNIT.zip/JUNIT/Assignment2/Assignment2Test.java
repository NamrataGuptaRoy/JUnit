import static org.junit.Assert.*;

import org.junit.Test;

public class Assignment2Test {

	@Test
	public void test() {
		Assignment2 ob=new Assignment2();
		int input[]= {2,6,5,8,1};
		int exp_arr[]={1,2,5,6,8};
		assertArrayEquals(exp_arr,ob.sortNumbers(input));
	}

}
