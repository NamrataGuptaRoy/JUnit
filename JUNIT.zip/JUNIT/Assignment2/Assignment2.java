import java.util.Arrays;

public class Assignment2 {
	int[] sortNumbers(int arr[])
	{
		Arrays.sort(arr);
		return arr;
	}
}
