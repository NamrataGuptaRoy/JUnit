import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class DBConnectionTest {
	DBConnection db=new DBConnection();
	String result="";
	@Before
	public void setUpBeforeClass() 
	{
		result=db.connect("abc","www.abc/xy.com", "User", "Password");
	}
	@Test
	public void test() {
		assertEquals("Success",result);
	}

}
