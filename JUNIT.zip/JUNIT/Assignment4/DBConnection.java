
public class DBConnection {
	String connect(String drivername,String url,String username,String pwd) 
	{
		String result="";
		if(drivername!=null && url!=null && username!=null && pwd!=null )result="Success";
		else result="Failure";
		return result;
	}
}
