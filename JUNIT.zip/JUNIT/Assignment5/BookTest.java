import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

@RunWith(Parameterized.class)
public class BookTest {
	int price;
	double discount;
	double final_price;
	Book b;
	
	@Before
	public void initialize()
	{
		b=new Book();
	}
	
	public BookTest(int price, double discount, double final_price)
	{
		this.price=price;
		this.discount=discount;
		this.final_price=final_price;
	}
	
	@Parameterized.Parameters
	   public static Collection books() {
	      return Arrays.asList(new Object[][] {
	         { 2000,250,1750 },
	         { 699,45,654 },
	         { 1920,220,1700  },
	         { 2200,250,1950  },
	         { 230,23,207 }
	      });
	   }

	@Test
	public void test() {
		System.out.println("Discounted Price is : " + final_price);
	      assertEquals(final_price, 
	     b.discountedPrice(price, discount),0.00);
	}

}
