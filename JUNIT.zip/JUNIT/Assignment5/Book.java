
public class Book {
	double discountedPrice(int price,double discount)
	{
		return (double)price-discount;
	}
}
